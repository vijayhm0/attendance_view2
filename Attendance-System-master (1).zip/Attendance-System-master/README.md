You need to have proper working Eclipse .
Import the project and play around . 
There is also a SMS sending feature which you can use to your own benefit.

In the emulator , you need to have the give the number of the emulator ( something like 5514) as the receipient number.
